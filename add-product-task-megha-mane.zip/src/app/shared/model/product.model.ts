// import { Ingredient } from "./ingredient.model";

export class Product{
    imgData : string;
  name : string;
 rupees : string;
qty:string;

 
  
  constructor(rImg : string,rName : string, rRuup : string, rQty: string){
    this.imgData = rImg;
 this.name = rName;
 this. rupees= rRuup;
this.qty =rQty;

  }
}